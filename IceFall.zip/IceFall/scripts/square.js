
export default class Square{
    constructor(ctx,x,y,arm,strokeColor,fillColor="aliceblue"){
        this.ctx=ctx;
        this.x=x;
        this.y=y;
        this.arm=arm;
        this.strokeColor=strokeColor;
        this.fillColor=fillColor;

    }

    draw(){
        

        // this.ctx.beginPath();
        this.ctx.fillStyle=this.fillColor;
        this.ctx.strokeStyle=this.strokeColor;
        this.ctx.fillRect(this.x,this.y,this.arm,this.arm);
        this.ctx.strokeRect(this.x,this.y,this.arm,this.arm);
        // this.ctx.fill();
        // this.ctx.closePath();

    }

    update(){
        console.log("Square update");
    }

}