
export default class Rect{
    constructor(ctx,x,y,width,height,strokeColor,fillColor="aliceblue"){
        this.ctx=ctx;
        this.x=x;
        this.y=y;
        this.width=width;
        this.height=height;
        this.storkeColor=strokeColor;
        this.fillColor=fillColor;
    }

    draw(){
        
        this.ctx.fillStyle=this.fillColor;
        this.ctx.strokeStyle=this.strokeColor;
        this.ctx.fillRect(this.x,this.y,this.height,this.width);
        this.ctx.strokeRect(this.x,this.y,this.height,this.width);
        // this.ctx.fill();
        // this.ctx.stroke();
        // this.ctx.closePath();
        
    }

    update(){
        console.log("Rectangle update");
    }

}