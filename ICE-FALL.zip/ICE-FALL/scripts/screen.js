import Circle from "./circle.js";
import Rect from "./rect.js";
import Square from "./square.js";
import Line from "./line.js";
// -------------------------------------
import Triangle from "./triangle.js";
import Polygon from "./polygon.js";
import Text from "./text.js";
import Ellipse from "./ellipse.js";

export default class Screen {
  constructor(width, height, borderRadius, logo = null) {
    this.screen = document.getElementById("canvas");
    this.ctx = this.screen.getContext("2d");
    this.screen.width = width;
    this.screen.height = height;
    this.borderRadius = borderRadius;
    this.logo = logo;
  }

  show() {
    
    this.screen.style.border = "1px solid red";
    this.screen.style.borderRadius = this.borderRadius + "px";
  }
  clear(){
    this.ctx.clearRect(0,0, this.screen.width, this.screen.height)
  }

  draw(obj) {
    obj.draw();
  }

  update(obj) {
    obj.update();
  }

  createCircle(x, y, radius, cStrokeColor, fillColor) {
    const obj = new Circle(this.ctx, x, y, radius, cStrokeColor, fillColor);
    return obj;
  }

  createSquare(x, y, arm, strokeColor, fillColor) {
    const obj = new Square(this.ctx, x, y, arm, strokeColor, fillColor);
    return obj;
  }

  createRect(x, y, height, width, strokeColor, fillColor) {
    const obj = new Rect(this.ctx, x, y, height, width, strokeColor, fillColor);
    return obj;
  }

  createLine(x1, y1, x2, y2, strokeColor) {
    const obj = new Line(this.ctx, x1, y1, x2, y2, strokeColor);
    return obj;
  }

  // -------------------------------------
  createTriangle(x1, y1, x2, y2, x3, y3, fillStyle, strokeStyle, lineWidth) {
    const obj = new Triangle(
      this.ctx,
      x1,
      y1,
      x2,
      y2,
      x3,
      y3,
      fillStyle,
      strokeStyle,
      lineWidth
    );
    return obj;
  }
  createEllipse(x, y, width, height, fillStyle, strokeStyle, lineWidth) {
    const obj = new Ellipse(
      this.ctx,
      x,
      y,
      width,
      height,
      fillStyle,
      strokeStyle,
      lineWidth
    );
    return obj;
  }
  createPolygon(n, size, x, y, fillStyle, strokeStyle, lineWidth) {
    const obj = new Polygon(
      this.ctx,
      n,
      size,
      x,
      y,
      fillStyle,
      strokeStyle,
      lineWidth
    );
    return obj;
  }
  createText(text, x, y, size, fontWeight, fillStyle, fontFamily) {
    const obj = new Text(
      this.ctx,
      text,
      x,
      y,
      size,
      fontWeight,
      fillStyle,
      fontFamily
    );
    return obj;
  }
}
