import Screen from "./screen.js";
const screen = new Screen(1000, 600, 20);
screen.show();
const canvas = screen.screen;
const position = canvas.getBoundingClientRect();
console.log(screen);

let drawObject;
let startX;
let startY;
let width;
let height;
let x2;
let y2;
let str="";
let object = [];
let r;
let textX;
let textY;
let mouseX=0;
let mouseY =0;
let startingX=0;
let write;
let onIcon = "select";
const colors = ["drakred", "lightgreen", "orange", "pink", "yellow", "lightcoral", "aliceblue", "royalblue"];
let pushObject = false;
let drawing = false;
let inputTag = document.createElement("input");
inputTag.style.position = "absolute";
inputTag.id = "textValue";
inputTag.autocomplete = "off";

// Add active class to the current button (highlight it)
let header = document.getElementById("sideNavbar");
let icon = header.getElementsByClassName("icon");

// draw object
function allDraw() {
    if (object.length > 0) {
        object.forEach(item => {
            screen.draw(item);
        });
    }
    else {
        return;
    }
}

function text(e) {
    if (onIcon === "text") {
        textX=Math.floor(e.pageX-canvas.offsetLeft);
        textY=Math.floor(e.pageY-canvas.offsetTop);
        mouseX= Math.floor(e.pageX-canvas.offsetLeft);
        mouseY = e.pageY-canvas.offsetTop;
        startingX=mouseX;
        return false;
    }

}
//Get Text value
function getValue(e) {

    console.log(e.keyCode);
    if (e.keyCode === 13) {
        screen.clear();
        object.push(screen.createText(str, textX, textY, 28, "bolder", "darkred", "Times New Roman"));
        allDraw();
        str="";
    }
    if(e.keyCode===8){
        screen.clear();
        str=str.slice(0,str.length - 1)
        screen.draw(screen.createText(str, textX, textY, 28, "bolder", colors[Math.random()*colors.length], "Times New Roman"));
        mouseX -= screen.ctx.measureText(e.key).width
        allDraw();
    }
    if(e.keyCode>=60 && e.keyCode<=90 || e.keyCode<=57 && e.keyCode >= 48 || e.keyCode===32){
        write = screen.createText(e.key, mouseX, mouseY, 28, "bolder", colors[Math.random()*colors.length], "Times New Roman");
        
        mouseX += screen.ctx.measureText(e.key).width;
        // screen.ctx.measureText(e.key).width
        str +=write.text;
        screen.draw(write);
        allDraw();
        console.log(write);
    }


    // }

}
function startDrawing(e) {

    e.preventDefault();

    drawing = true;


    startX = Math.floor(e.offsetX);
    startY = Math.floor(e.offsetY);
    console.log(startX, startY);
}

function continueDrawing(e) {
    e.preventDefault();
    pushObject = true;
    if (!drawing) {
        pushObject = false;
        return;
    }

    screen.clear();
    allDraw();
    switch (onIcon) {
        case "select":
            pushObject = false;
            allDraw();
            break;
        case "circle":
            allDraw();
            r = Math.floor(Math.sqrt(Math.pow(parseInt(startX - e.offsetX), 2) + Math.pow(parseInt(startY - e.offsetY), 2)));
            drawObject = screen.createCircle(startX, startY, r, "black", colors[Math.floor(Math.random() * colors.length)]);
            screen.draw(drawObject);
            break;
        case "rectangle":
            allDraw();
            width = e.offsetX - startX; // ending x position - start x position
            height = e.offsetY - startY// ending y position - start y position
            drawObject = screen.createRect(startX, startY, width, height, "black", colors[Math.floor(Math.random() * colors.length)]);
            screen.draw(drawObject);
            break;
        case "line":
            screen.clear();
            allDraw();
            x2 = e.offsetX;
            y2 = e.offsetY;
            drawObject = screen.createLine(startX, startY, x2, y2)
            screen.draw(drawObject);
            break;
        case "triangle":
            screen.clear();
            drawObject=screen.createTriangle(startX,startY,e.offsetX,e.offsetY,startX * 2 - e.offsetX, e.offsetY,"lightgreen","black",2);
            screen.draw(drawObject);
            allDraw();
            break;
    }

}
// context.moveTo(startPoint.x, startPoint.y);
// context.lineTo(e.offsetX, e.offsetY);
// context.lineTo(startPoint.x * 2 - e.offsetX, e.offsetY);


function endDrawing(e) {
    e.preventDefault();
    drawing = false;
    if (pushObject) {
        object.push(drawObject);
    }
    allDraw();

}




screen.screen.onmousedown = startDrawing;
screen.screen.onmousemove = continueDrawing;
screen.screen.onmouseup = endDrawing;
canvas.onclick = text;
window.onkeydown = getValue;

for (let i = 0; i < icon.length; i++) {

    icon[i].addEventListener("click", function () {
        let current = document.getElementsByClassName("active");
        current[0].className = current[0].className.replace(" active", "");
        onIcon = this.name;
        console.log(onIcon);
        this.className += " active";

    });
}
